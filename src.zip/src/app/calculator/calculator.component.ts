import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit {
  constructor() { }
  currNumber='0';
  firstOperand=0;
  operator:any;
  secondNumber=false;
  ngOnInit(): void {
  }

  public getNumber(v:string){
    console.log(v);
    if(this.secondNumber){
      this.currNumber=v;
      this.secondNumber=false;
    }else{
      this.currNumber==='0'?this.currNumber=v: this.currNumber+=v;
    }
  }

  getDecimal(){
    if(!this.currNumber.includes('.')){
      this.currNumber+='.';
    }
  }


private calculate(op: any,secondOperand: any ){
  switch(op){
    case '+':
      return this.firstOperand += secondOperand; 
      case '-': 
      return this.firstOperand -= secondOperand; 
      case '*': 
      return this.firstOperand *= secondOperand; 
      case '/': 
      return this.firstOperand /= secondOperand; 
      case '=':
      return secondOperand;
      
  }
}

public getOperation(op: string){
  console.log(op);

  if(this.firstOperand === Number(this.secondNumber)){
    this.firstOperand = Number(this.currNumber);

  }
  else if(this.operator){
    const result = this.calculate(this.operator , Number(this.currNumber))
    this.currNumber = String(result); //to print on input text
    this.firstOperand = result;
    console.log(this.firstOperand);
 
  }
 
  this.operator = op;
  this.secondNumber = true; 

  // console.log(this.firstOperand);

}

 public clear(){
    this.currNumber = '0';
    this.firstOperand = 0;
    this.operator = null;
    this.secondNumber = false;
  }

}
